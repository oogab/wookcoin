package main

import (
	"github.com/oogab/wookcoin/cli"
)

func main() {
	// go explorer.Start(3000)
	cli.Start()
}
